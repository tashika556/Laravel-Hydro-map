<?php $__env->startSection('page_title','Album Details'); ?>
<?php $__env->startSection('container'); ?>



<section class="banner_div text-center">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid grid-cols-1">
            <div class="col-span-1">
                <div class="banner_div">
                    <h1 class="relative"><?php echo e($gallery['name']); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>



<section id="gallery">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">

        <div class="grid grid-cols-3 gap-7">
        <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-span-1">
        <div class="img-wrapper">
            <a href="<?php echo e(asset('images/' . $photo->image)); ?>" data-lightbox="gallery" data-title="Image <?php echo e($loop->iteration); ?>">
                <img src="<?php echo e(asset('images/' . $photo->image)); ?>" class="img-responsive">
            </a>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Add this to your HTML file -->
<script>

</script>

        </div><!-- End row -->

    </div><!-- End container -->
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('content-link'); ?>
<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="flex justify-center space-x-5">
        <a href="<?php echo e($company['facebook']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/facebook-new.png" />
        </a>

        <a href="<?php echo e($company['instagram']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/instagram-new.png" />
        </a>
        <a href="<?php echo e($company['youtube']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/youtube.png" />
        </a>
        <a href="<?php echo e($company['twitter']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/twitter.png" />
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/gallerydetails.blade.php ENDPATH**/ ?>