<?php $__env->startSection('page_title','Edit About Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="pe-md-3 d-flex align-items-center">
        <a href="<?php echo e(url('admin/about')); ?>">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
        </a>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('container'); ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bg-white p-4">
                <form action="<?php echo e(url('admin/editsaboutdetails/'.$about_details->id)); ?>" method="post" enctype="multipart/form-data">
   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="introduction">Introduction</label>
                                    <textarea name="introduction"
                                        class="form-control"><?php echo e($about_details['introduction']); ?></textarea>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="photos">Featured Image</label>
                    <input type="file" name="photo" class="form-control">
                    <img src="<?php echo e(asset('uploads/aboutdetails/'.$about_details->photo)); ?>">

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Video URL</label>
                    <input type="text" name="video_url" class="form-control" value="<?php echo e($about_details['video_url']); ?>">

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Hydropower Total</label>
                    <input type="text" name="count_hydropower" class="form-control" value="<?php echo e($about_details['count_hydropower']); ?>">

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Running Projects Total</label>
                    <input type="text" name="count_runproject" class="form-control" value="<?php echo e($about_details['count_runproject']); ?>">

                                </div>
                            </div>

                            
                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="count_company">Companies Total</label>
                    <input type="text" name="count_company" class="form-control" value="<?php echo e($about_details['count_company']); ?>">

                                </div>
                            </div>

                            
                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">International Financiers Total</label>
                    <input type="text" name="count_intfinancier" class="form-control" value="<?php echo e($about_details['count_intfinancier']); ?>">

                                </div>
                            </div>

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-danger" value="Edit About Details">
                        </div>

                        <?php if(Session::has('success')): ?>
                        <button class="btn btn-success"><?php echo e(Session::get('success')); ?></button> <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/editaboutdetails.blade.php ENDPATH**/ ?>