<?php $__env->startSection('page_title','Edit Blog Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="pe-md-3 d-flex align-items-center">
        <a href="<?php echo e(url('admin/blog')); ?>">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
        </a>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('container'); ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bg-white p-4">
                <form action="<?php echo e(url('admin/editsblogdetails/'.$blog_details->id)); ?>" method="post" enctype="multipart/form-data">
   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                        <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($blog_details['title']); ?>">

                                </div>
                            </div>

                       
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="introduction">Description</label>
                                    <textarea name="description" class="form-control"><?php echo e($blog_details['description']); ?></textarea>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Month</label>
                    <input type="text" name="month" class="form-control" value="<?php echo e($blog_details['month']); ?>">

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="modelyear">Date</label>
                    <input type="text" name="date" class="form-control" value="<?php echo e($blog_details['date']); ?>">

                                </div>
                            </div>

                            
                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="count_company">Year</label>
                    <input type="text" name="year" class="form-control" value="<?php echo e($blog_details['year']); ?>">

                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="photos">Featured Image</label>
                    <input type="file" name="image" class="form-control">
                    <img src="<?php echo e(asset('uploads/blogdetails/'.$blog_details->image)); ?>">

                                </div>
                            </div>
                            
                                              

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-danger" value="Edit blog Details">
                        </div>

                        <?php if(Session::has('success')): ?>
                        <button class="btn btn-success"><?php echo e(Session::get('success')); ?></button> <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/editblogdetails.blade.php ENDPATH**/ ?>