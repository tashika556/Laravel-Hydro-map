<?php $__env->startSection('page_title','Company List'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="pe-md-3 d-flex align-items-center">
          <a href="<?php echo e(route('add_company')); ?>">
  <button class="btn btn-danger">Add Company Details</button>
</a>
          </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-10">
            <table class="bg-white table">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Company Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($company['company_name']); ?></td>
                        <td>
                        <a href="<?php echo e(url('admin/editcompanydetails')); ?>/<?php echo e($company->id); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('admin/company/delete')); ?>/<?php echo e($company->id); ?>" class="btn btn-danger" title="Delete">Delete</a>
                        </td>
                    </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has('fail')): ?>
                <button class="btn btn-danger"><?php echo e(Session::get('fail')); ?></button>    <?php endif; ?>  
                    <!-- Add more rows as needed -->
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/company.blade.php ENDPATH**/ ?>