<?php $__env->startSection('page_title', 'Gallery'); ?>
<?php $__env->startSection('container'); ?>

<!-- Banner Section -->
<section class="banner_div text-center">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid grid-cols-1">
            <div class="col-span-1">
                <div class="banner_div">
                    <h1 class="relative"><?php echo $__env->yieldContent('page_title'); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid grid-cols-3 gap-8">

        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-span-1" id="album<?php echo e($gallery->id); ?>">
            <div class="gallery-box">
                <div class="gallery_img-main">

                    <a href="gallerydetails/<?php echo e($gallery->id); ?>">
                    <img src="<?php echo e(asset('images/' . $gallery->featured_image)); ?>" alt="<?php echo e($gallery->name); ?>">
                    </a>
       
                </div>
                <h3><?php echo e($gallery->name); ?></h3>
            <p>Number of Photos: <?php echo e($gallery->photos->count()); ?></p>
            </div></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<!-- Social Links Section -->
<?php $__env->startSection('content-link'); ?>
<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="flex justify-center space-x-5">
    <a href="<?php echo e($company['facebook']); ?>" target="_blank" rel="noopener noreferrer">
        <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/facebook-new.png" />
    </a>
    <a href="<?php echo e($company['instagram']); ?>" target="_blank" rel="noopener noreferrer">
        <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/instagram-new.png" />
    </a>
    <a href="<?php echo e($company['youtube']); ?>" target="_blank" rel="noopener noreferrer">
        <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/youtube.png" />
    </a>
    <a href="<?php echo e($company['twitter']); ?>" target="_blank" rel="noopener noreferrer">
        <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/twitter.png" />
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/gallery.blade.php ENDPATH**/ ?>