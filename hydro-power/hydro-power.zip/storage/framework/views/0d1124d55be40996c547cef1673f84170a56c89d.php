<?php $__env->startSection('page_title', 'Gallery List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
        <div class="pe-md-3 d-flex align-items-center">
            <a href="<?php echo e(route('add_gallery')); ?>">
                <button class="btn btn-danger">Add Gallery Album</button>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-10">
                <table class="bg-white table">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Album Name</th>
                            <th>Number of Photos</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($gallery->name); ?></td>
                                <td><?php echo e($gallery->photos_count); ?></td>
                                <td>
                                <a href="<?php echo e(url('admin/editgallerydetails')); ?>/<?php echo e($gallery->id); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('admin/gallery/delete')); ?>/<?php echo e($gallery->id); ?>" class="btn btn-danger" title="Delete">Delete</a>
                        </td>
                    </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has('fail')): ?>
                <button class="btn btn-danger"><?php echo e(Session::get('fail')); ?></button>    <?php endif; ?>
                            </tr>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/gallery.blade.php ENDPATH**/ ?>