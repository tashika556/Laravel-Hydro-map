<?php $__env->startSection('page_title','Edit Project Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="pe-md-3 d-flex align-items-center">
        <a href="<?php echo e(url('admin/project')); ?>">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
        </a>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('container'); ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bg-white p-4">
                <form action="<?php echo e(url('admin/editsprojectdetails/'.$project_details->id)); ?>" method="post" enctype="multipart/form-data">
   
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Project Name</label>
                                    <input type="text" name="project_name" class="form-control" value="<?php echo e($project_details['project_name']); ?>" required>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Latitude</label>
                                    <input type="text" name="latitude" class="form-control" value="<?php echo e($project_details['latitude']); ?>" required>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Longitude</label>
                                    <input type="text" name="longitude" class="form-control" value="<?php echo e($project_details['longitude']); ?>" required>

                                </div>
                            </div>



                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Description</label>
                                    <textarea name="description" class="form-control"><?php echo e($project_details['description']); ?></textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Summary</label>
                                    <textarea name="summary" class="form-control"><?php echo e($project_details['summary']); ?></textarea>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Project Impacts</label>
                                    <textarea name="impacts" class="form-control"><?php echo e($project_details['impacts']); ?></textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Advocacies Undertaken</label>
                                    <textarea name="advocacies_undertaken" class="form-control"><?php echo e($project_details['advocacies_undertaken']); ?></textarea>
                                </div>
                            </div>


                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Rights violated as per national/international laws</label>
                                    <textarea name="rights" class="form-control"><?php echo e($project_details['rights']); ?></textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Location</label>
                                    <input type="text" name="location" class="form-control" value="<?php echo e($project_details['location']); ?>">
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Budget</label>
                                    <input type="text" name="budget" class="form-control" value="<?php echo e($project_details['budget']); ?>">
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Affected Communities</label>
                                    <input type="text" name="affected_communities" class="form-control" value="<?php echo e($project_details['affected_communities']); ?>">
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Start of Conflict</label>
                                    <input type="text" name="conflict_start" class="form-control" value="<?php echo e($project_details['conflict_start']); ?>">
                                </div>
                            </div>

                            <div class="col-4">
    <div class="form-group mb-4">
        <label for="title">Company Name</label>
        <?php $__currentLoopData = $data['companies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex items-center py-3">
                <input type="checkbox" name="companies[]" class="company-checkbox input_width border-gray-300 rounded" value="<?php echo e($company->id); ?>"
                    <?php if(in_array($company->id, $project_details->companies->pluck('id')->toArray())): ?> checked <?php endif; ?> />
                <span class="mx-1"><?php echo e($company->company_name); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Relevant Government Actors</label>
                                    <textarea name="government_actors" class="form-control"><?php echo e($project_details['government_actors']); ?></textarea>
                                </div>
                            </div>

                            <div class="col-4">
    <div class="form-group mb-4">
        <label for="title">International Financiers</label>
        <?php $__currentLoopData = $dataa['financiers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex items-center py-3">
                <input type="checkbox" name="international_finances[]" class="input_width border-gray-300 rounded" value="<?php echo e($financier->id); ?>"
                    <?php if(in_array($financier->id, $project_details->international_finances->pluck('id')->toArray())): ?> checked <?php endif; ?> />
                <span class="mx-1"><?php echo e($financier->fin_name); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Advocacy Organizations</label>
                                    <textarea name="advocacy_org" class="form-control"><?php echo e($project_details['advocacy_org']); ?></textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Relevant Links</label>
                                    <textarea name="relevant_link" class="form-control"><?php echo e($project_details['relevant_link']); ?></textarea>
                                </div>
                            </div>

                        </div>

                        <div class="form-group">
                            <input type="submit" class="btn btn-danger" value="Edit project Details">
                        </div>

                        <?php if(Session::has('success')): ?>
                        <button class="btn btn-success"><?php echo e(Session::get('success')); ?></button> <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/editprojectdetails.blade.php ENDPATH**/ ?>