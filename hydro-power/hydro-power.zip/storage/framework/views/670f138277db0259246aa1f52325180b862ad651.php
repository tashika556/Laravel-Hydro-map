<?php $__env->startSection('page_title','Add Blog Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="pe-md-3 d-flex align-items-center">
        <a href="<?php echo e(url('admin/blog')); ?>">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
        </a>
    </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('container'); ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bg-white p-4">
                    <form action="<?php echo e(route('added_blog')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Title</label>
                                    <input type="text" name="title" class="form-control" required>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Month</label>
                                    <input type="text" name="month" class="form-control" required>

                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Date</label>
                                    <input type="text" name="date" class="form-control" required>

                                </div>
                            </div>



                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Year</label>
                                    <input type="text" name="year" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group mb-4">
                                    <label for="title">Description</label>
                                    <textarea name="description" class="form-control"></textarea>
                                </div>
                            </div>
                       
                            <div class="col-4">
                                <div class="form-group mb-4">
                                <label for="image">Image</label>
                    <input type="file" name="image" class="form-control">
                                </div>
                            </div>
                        </div>      

                        <div class="form-group">
                            <input type="submit" class="btn btn-danger" value="Add Blog Details">
                        </div>
                        
                        <?php if(Session::has('success')): ?>
                <button class="btn btn-success"><?php echo e(Session::get('success')); ?></button>    <?php endif; ?>  
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/add_blog_details.blade.php ENDPATH**/ ?>