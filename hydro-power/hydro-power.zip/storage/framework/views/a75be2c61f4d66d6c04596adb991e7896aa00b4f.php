<div>
    <div class="form-group mb-4 border-bottom pb-4">
        <label for="title">Images</label><br>
        <input type="file" wire:model="images" accept="image/*" multiple>

        <div id="imagesPreview" class="image-preview">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="image-wrapper">
                    <img src="<?php echo e($image->temporaryUrl()); ?>" alt="Image Preview" class="img-thumbnail">
                    <span class="remove-icon" wire:click="removeImage(<?php echo e($index); ?>)">&#10060;</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/livewire/image-uploader.blade.php ENDPATH**/ ?>