<?php $__env->startSection('page_title','Blog'); ?>
<?php $__env->startSection('container'); ?>



<?php $__env->startSection('content'); ?>
<section class="banner_div text-center">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid grid-cols-1">
            <div class="col-span-1">
                <div class="banner_div">
                    <h1 class="relative"><?php echo $__env->yieldContent('page_title'); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<section class="relative bg-gray-200">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 lg:gap-8 gap-4">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-span-1">
                <div class=" bg-white mb-md-4 mb-3 relative">
                    <div class="news_img">
                        <img src="<?php echo e(asset('uploads/blogdetails/'.$company->image)); ?>" class="img-fluid w-full">
                    </div>
                    <div class="blog_date">
                        <h5><strong><?php echo e($company['date']); ?></strong> <span><?php echo e($company['month']); ?></span></h5>
                    </div>
                    <div class="news_content flex justify-center flex-col">
                        <div class="my-3">
                            <h4><?php echo e($company['title']); ?></h4>
                        </div>

                        <div class="readmore-line">
                            <a href="ViewBlogDetails/<?php echo e($company->id); ?>" class="site-button-link" data-hover="Read More">Read More <i class="fa fa-angle-right arrow-animation" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>

</div><?php $__env->stopSection(); ?>

<?php $__env->startSection('content-link'); ?>
<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="flex justify-center space-x-5">
        <a href="<?php echo e($company['facebook']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/facebook-new.png" />
        </a>

        <a href="<?php echo e($company['instagram']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/instagram-new.png" />
        </a>
        <a href="<?php echo e($company['youtube']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/youtube.png" />
        </a>
        <a href="<?php echo e($company['twitter']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/twitter.png" />
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/blog.blade.php ENDPATH**/ ?>