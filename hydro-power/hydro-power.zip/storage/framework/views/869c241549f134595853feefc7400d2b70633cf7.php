<?php $__env->startSection('page_title','About List'); ?>



<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-10">
     
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row">
                <div class="col-4">
                    <div class="bg-white p-4">
                        <h1>Introduction</h1>
                    <p>
                    <?php echo e($company['introduction']); ?>

                    </p>
                    <a href="<?php echo e(url('admin/editaboutdetails')); ?>/<?php echo e($company->id); ?>" class="btn btn-success">Edit</a>
                </div>
                </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/about.blade.php ENDPATH**/ ?>