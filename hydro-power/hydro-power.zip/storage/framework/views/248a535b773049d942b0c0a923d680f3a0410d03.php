<?php $__env->startSection('page_title','Project List'); ?>

<?php $__env->startSection('content'); ?>
<div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
    <div class="pe-md-3 d-flex align-items-center">
        <a href="<?php echo e(route('add_project')); ?>">
            <button class="btn btn-danger">Add Project</button>
        </a>
    </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <table class="bg-white table">
                    <thead>
                        <tr>
                            <th class="border">S.No.</th>
                            <th class="border">Project Name</th>
                         
            
                            <th class="border">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border"><?php echo e($loop->index+1); ?></td>
                            <td  class="border"><?php echo e($member->project_name); ?></td>
             
                 
<td  class="border">
<a href="<?php echo e(url('admin/editprojectdetails')); ?>/<?php echo e($member->id); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('admin/project/delete')); ?>/<?php echo e($member->id); ?>" class="btn btn-danger" title="Delete">Delete</a>
                        </td>
                    </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has('fail')): ?>
                <button class="btn btn-danger"><?php echo e(Session::get('fail')); ?></button>    <?php endif; ?>  
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/admin/project.blade.php ENDPATH**/ ?>