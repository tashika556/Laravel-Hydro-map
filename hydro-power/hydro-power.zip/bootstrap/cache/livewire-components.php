<?php return array (
  'image-uploader' => 'App\\Http\\Livewire\\ImageUploader',
);