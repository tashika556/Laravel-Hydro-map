<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InternationalFinances extends Model
{
    protected $table= 'international_finances';
    protected $fillable=[
'fin_name',
'fin_icon',

    ];

}
