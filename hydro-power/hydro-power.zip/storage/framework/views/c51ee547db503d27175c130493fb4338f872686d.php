<?php $__env->startSection('page_title','Contact'); ?>
<?php $__env->startSection('container'); ?>



<?php $__env->startSection('content'); ?>
<section class="banner_div text-center">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5">
        <div class="grid grid-cols-1">
            <div class="col-span-1">
                <div class="banner_div">
                    <h1 class="relative"><?php echo $__env->yieldContent('page_title'); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="contact image-bg relative">
    <div class="mx-auto max-w-7xl lg:px-0 md:px-8 px-5 z-10 relative">
        <div class="grid lg:grid-cols-9">
            <div class="col-start-2 col-span-7">
                <div class="content-div relative flex flex-col justify-center">
                    <div class="contact-box bg-gray-700 lg:p-10 p-5 rounded-2xl shadow-2xl">
                        <div class="contact_wrap">
                            <div class="div-title">
                               
                                <h2 class=" text-white">
                                <?php echo $__env->yieldContent('page_title'); ?></h2>
                            </div>
                            <div class="text-contact border-b-2 border-opacity-10 py-4">
                                <h3 class="text-white lg:text-4xl text-3x1  mb-2">Address</h2>
                                    <p class="text-white text-lg"><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo e($company['address1']); ?></p>
                            </div>
                            <div class="text-contact border-b-2 border-opacity-10 py-4">
                                <h3 class="text-white lg:text-4xl text-3x1  mb-2">Phone</h2>
                                    <p class="text-white text-lg"><i class="fa fa-phone transform rotate-90" aria-hidden="true"></i><?php echo e($company['phone1']); ?></p>
                            </div>
                            <div class="text-contact border-b-2 border-opacity-10 py-4">
                                <h3 class="text-white lg:text-4xl text-3x1  mb-2">Email</h2>
                                    <p class="text-white text-lg"><i class="fa fa-envelope" aria-hidden="true"></i><?php echo e($company['email1']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</div><?php $__env->stopSection(); ?>

<?php $__env->startSection('content-link'); ?>
<div class="flex justify-center space-x-5">
        <a href="<?php echo e($company['facebook']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/facebook-new.png" />
        </a>

        <a href="<?php echo e($company['instagram']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/instagram-new.png" />
        </a>
        <a href="<?php echo e($company['youtube']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/youtube.png" />
        </a>
        <a href="<?php echo e($company['twitter']); ?>" target="_blank" rel="noopener noreferrer">
            <img class="icons_footer" src="https://img.icons8.com/fluent/30/000000/twitter.png" />
        </a>
    </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_hydro\hydro-power\resources\views/contact.blade.php ENDPATH**/ ?>